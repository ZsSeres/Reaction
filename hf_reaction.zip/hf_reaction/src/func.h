//Includok
	//Em_lib
	#include "em_device.h"
	#include "em_chip.h"
	#include "em_lcd.h"
	#include"em_usart.h"
	#include"em_cmu.h"
	#include "em_gpio.h"
	//Drivers
	#include "segmentlcd.h"
	#include "retargetserial.h"
	//C k�nyvt�rak
	#include "stdio.h"

//F�ggv�nyek
//Magyar�zat:func.c-be!
//Cosmetics
void start_cosmetic();
void finish_cosmetic(char kert, int hibaszam, int tms);
//Random gener�l�s
int randomizer(int lower,int upper);
//K�sleltet�s
void delay(int offs, int random);
//Inicializ�l� fv-k
void init_uart();
void init_all();
//Reakci�id� m�r�s�hez sz�ks�ges fv-k
int timer_offs_calculate();
int timertotms(int timer, int timer_offs, int counter);
