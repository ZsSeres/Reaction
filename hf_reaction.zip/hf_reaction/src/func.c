#include "func.h"


void start_cosmetic() //program indul�sakor, kezd�sz�veg ki�r�sa
  {
	  int i=0;
	  printf("\n");
	  for (i=0;i<10;i++)
	  {
		  printf("|");
	  }
	  printf("START");
	  for (i=0;i<10;i++)
	  {
		  printf("|");
	  }
	  printf("\n");
	  printf("Ready? Press any key!\n");
  }

  void finish_cosmetic(char kert, int hibaszam, int tms)//program v�gezt�vel, UART-ra ki�rjuk a k�rt karaktert, a hibasz�mot �s a reakci�id�t, LCD-re csak a reakci�id�t
  {
	  printf("REQ:%c ERROR:%d RT:%d ms\n",kert,hibaszam,tms);
	  SegmentLCD_Number(tms);

	  int i=0;
	  for (i=0;i<10;i++)
	  {
		  printf("|");
	  }
	  printf("GAME OVER");
	  for (i=0;i<10;i++)
	  {
		  printf("|");
	  }
	  printf("\n");
  }

  int randomizer(int lower,int upper)//lower �s upper k�z�tt gener�l egy random sz�mot
  {
	  int i;
	  int random;
	  char en='\0';
	  for(i=lower;i<upper+1;i++){
	  	if(i==upper)
	  	{
	  		i=lower;
	  	}
	  	scanf("%c",&en);
	  	if(en!='\0')
	  	{
	  		random=i;
	  		return random;
	  	}

	  }

  }
  void delay(int offs, int random)//k�sleltet�st gener�l, megadhat� neki egy fix k�sleltet�s,+ a fix k�sleltet�s ut�n egy random
  {

	USART_Enable(UART0,usartEnableTx  );
	int cycles = (offs+random)*14000;
    int start = DWT->CYCCNT;
    while(DWT->CYCCNT - start < cycles){}
    USART_Enable(UART0,usartEnable );


  }

  void init_uart()//UART Inicializ�l�sa
  {
	  CMU->HFPERCLKEN0 |= CMU_HFPERCLKEN0_GPIO;
	  GPIO_PinModeSet(gpioPortF, 7, gpioModePushPull, 1);
	  CMU_ClockEnable(cmuClock_UART0, true);
	  //UART
	  USART_InitAsync_TypeDef UART0_init = USART_INITASYNC_DEFAULT;
	  USART_InitAsync(UART0, &UART0_init);
	  GPIO_PinModeSet(gpioPortE, 0, gpioModePushPull, 1);
	  GPIO_PinModeSet(gpioPortE, 1, gpioModeInput, 0);
	  UART0->ROUTE |= UART_ROUTE_LOCATION_LOC1;
	  UART0->ROUTE |= UART_ROUTE_TXPEN | UART_ROUTE_RXPEN;
  };

  void init_all()//LCD,UART,Retarget inicializ�l�sa
  {
	  CHIP_Init();
	  init_uart();
	  //LCD
	  SegmentLCD_Init(false);
	  //print init
	  RETARGET_SerialInit();
	  RETARGET_SerialCrLf(true);
  }

 /*int scanf_calculate()
 {
	 int i;
	 int timer_scanf;
	 char c;
	 timer_scanf=DWT->CYCCNT;
	 for (i=0;i<50;i++)
	 {
		 scanf("%c",&c);
	 }
	 timer_scanf=DWT->CYCCNT-timer_scanf;
	 timer_scanf=timer_scanf/50;
	 return timer_scanf;
 }*/


  int timer_offs_calculate()//Kisz�m�tja, hogy h�ny �rajelciklus az egyes utas�t�sok hossza, kb ezek az utsa�t�sok szerepelnek a main fv-be ind�tott timer ind�t�sa �s z�r�sa k�z�tt
  {
	  int scanf_offs=100;
	  int j=1;
	  int timer_offs;
	  timer_offs = DWT->CYCCNT;
	  while(1){
		  int r=0;
		  if(j==1){
			  if(j==1)
			  {
			  }
		  }
		  break;
	  }
	  timer_offs = DWT->CYCCNT - timer_offs+scanf_offs;
	  return timer_offs;
  }


int timertotms(int timer, int timer_offs, int counter)//kivonja az offsetet, azt�n az �rajelperi�dusok sz�m�t konvert�lja milisec-be
{
  int tms;
  timer =timer-(counter*timer_offs);
  tms=((double)timer/(CMU_ClockFreqGet(cmuClock_CORE))*1000);//1.0/((CMU_ClockFreqGet(cmuClock_CORE))*100000000)
  return tms;
}
