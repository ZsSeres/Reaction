#include "func.h"
/*REAKCIÓIDŐ MÉRŐ
 *
 * Készítette:
 * Kékesi Péter
 * Seres Zsombor
 *
 */



int main(void)
{
//Változók inicializálása
	char received='\0';//a karakter amit kapunk a felhasználótól
   uint32_t timer=0; //eltelt idő órajel ciklusokba mérve
   int timer_offs=0; // a program miatti offsetek
   int hibaszam=0;
   int tms=0; //reakció idő ms mértékegységbe
   int random;
   char kert='\0';
   int counter;//main fv-ben az eltelt while ciklusok száma

//Inicializálás
   init_all();

//Kezdő lépések
   start_cosmetic();//kis kozmetika
  timer_offs=timer_offs_calculate();
  random=randomizer(0,26);//egy random szám generálása
  printf("Check card LCD!");
  delay(3000,random*100); //Késleltetés
  kert=(char)(random+97);//szám átalakítása az angol abc vmely karakterévé
  SegmentLCD_Write(&kert);
  printf("\n");
  timer = DWT->CYCCNT;//"timer indítása"

  /* Infinite loop */
  while (1)
  {
	 received='\0';
	 scanf("%c",&received);
	  if(received!='\0')
	  {
	  if(received==kert)
	  {
		  timer = DWT->CYCCNT - timer;//Timer lekapcsolása
		  tms=timertotms(timer,timer_offs,counter);//órajelciklus->ms
		  finish_cosmetic(kert,hibaszam,tms);//LCD-re és UART-ra kiírás.
		  return 0;
	  }
	  else
	  {
		  hibaszam=hibaszam+1;
		  printf("ERROR!\n");
	  }
	  }

	  counter++;
  }
  }



